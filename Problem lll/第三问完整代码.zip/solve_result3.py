"""问题三：二维轴对称守恒模型、长时干燥计算与数值检验。

运行：
    python solve_result3.py --mode all
    python solve_result3.py --mode solve
    python solve_result3.py --mode conservation
    python solve_result3.py --mode steady
    python solve_result3.py --mode spatial
    python solve_result3.py --mode temporal
    python solve_result3.py --mode rebound

依赖：numpy、openpyxl。题目附件须位于本文件同目录下的“附件”文件夹。
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import q3_2d_model
import q3_grid_convergence
import q3_moisture_balance
import q3_surface_rebound_check
import q3_time_convergence
import q3_uniform_steady_test


def run_solve() -> None:
    """计算第三问主模型并写出 result3.xlsx。"""
    q3_2d_model.main()


def run_conservation() -> None:
    """检验内部水分变化与所有表面累计传质量是否闭合。"""
    q3_moisture_balance.main()


def run_steady() -> None:
    """检验均匀场和均匀边界下是否产生人工漂移。"""
    q3_uniform_steady_test.main()


def run_spatial() -> None:
    """执行粗、中、细三组空间网格的收敛与 Richardson 外推。"""
    q3_grid_convergence.main()


def run_temporal() -> None:
    """执行固定空间网格下的时间步长不敏感性检验。"""
    q3_time_convergence.main()


def run_rebound() -> None:
    """检查过渡阶段表面水分回升是否随网格加密而消失。"""
    q3_surface_rebound_check.main()


TASKS = {
    "solve": ("第三问主模型", run_solve),
    "conservation": ("全局水分守恒检验", run_conservation),
    "steady": ("均匀稳态检验", run_steady),
    "spatial": ("空间网格收敛检验", run_spatial),
    "temporal": ("时间步长检验", run_temporal),
    "rebound": ("表面水分回升检验", run_rebound),
}


def run_tasks(names: list[str]) -> None:
    started = time.time()
    for name in names:
        title, function = TASKS[name]
        print(f"\n========== {title} ==========")
        task_start = time.time()
        function()
        print(f"{title} 完成，用时 {time.time() - task_start:.2f} s")
    print(f"\n全部任务完成，总用时 {time.time() - started:.2f} s")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="问题三二维轴对称干燥模型与数值检验"
    )
    parser.add_argument(
        "--mode",
        choices=["all", *TASKS.keys()],
        default="all",
        help="选择运行主模型或某项数值检验",
    )
    arguments = parser.parse_args()
    if arguments.mode == "all":
        run_tasks(list(TASKS.keys()))
    else:
        run_tasks([arguments.mode])


if __name__ == "__main__":
    main()
