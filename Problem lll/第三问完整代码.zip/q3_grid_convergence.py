"""Grid convergence and Richardson extrapolation for question 3."""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

import q3_2d_model as model


BASE_DIR = Path(__file__).resolve().parent
REFINEMENT_RATIO = 1.5
GRID_LEVELS = [
    ("粗网格", 10, 20),
    ("中网格", 15, 30),
    ("细网格", 20, 40),
]
HEADER_FILL = PatternFill("solid", fgColor="D9EAF7")


def main() -> None:
    original_n_radial = model.N_RADIAL
    original_n_axial = model.N_AXIAL
    original_dt = model.DT
    records = []

    try:
        for name, n_radial, n_axial in GRID_LEVELS:
            model.N_RADIAL = n_radial
            model.N_AXIAL = n_axial
            model.DT = 2.5
            start_time = time.perf_counter()
            result = model.simulate()
            elapsed = time.perf_counter() - start_time
            times = result["time_s"]
            concentrations = result["moisture_kg_per_kg"]
            records.append(
                {
                    "name": name,
                    "n_radial": n_radial,
                    "n_axial": n_axial,
                    "nodes": (n_radial + 1) * (n_axial + 1),
                    "dt": model.DT,
                    "dry_hours": float(times[-1] / 3600.0),
                    "final_max": float(concentrations[-1].max()),
                    "iterations": float(result["average_iterations"]),
                    "elapsed": elapsed,
                }
            )
    finally:
        model.N_RADIAL = original_n_radial
        model.N_AXIAL = original_n_axial
        model.DT = original_dt

    coarse = records[0]["dry_hours"]
    medium = records[1]["dry_hours"]
    fine = records[2]["dry_hours"]
    numerator = fine - medium
    denominator = medium - coarse
    if (
        abs(numerator) < 1.0e-14
        or abs(denominator) < 1.0e-14
        or np.sign(numerator) != np.sign(denominator)
    ):
        order = float("nan")
    else:
        order = float(
            np.log(abs(denominator / numerator))
            / np.log(REFINEMENT_RATIO)
        )
    if not np.isfinite(order) or np.isclose(order, 0.0):
        richardson = float("nan")
    else:
        richardson = float(
            fine + (fine - medium) / (REFINEMENT_RATIO**order - 1)
        )

    lines = [
        "# 第三问网格收敛检验",
        "",
        "## 设置",
        "",
        "固定隐式 RK4 时间步长 2.5 s，只加密空间网格。相邻网格的线性尺度和节点间距倍率均为 1.5。",
        "",
        "## 结果",
        "",
        "| 网格 | 径向单元 | 轴向单元 | 节点数 | 烘干时间/h | 最终最大含水率 | 平均迭代次数 | 计算耗时/s |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for record in records:
        lines.append(
            f"| {record['name']} | {record['n_radial']} | "
            f"{record['n_axial']} | {record['nodes']} | "
            f"{record['dry_hours']:.6f} | "
            f"{record['final_max']:.6f} | "
            f"{record['iterations']:.3f} | "
            f"{record['elapsed']:.2f} |"
        )

    lines.extend(
        [
            "",
            "## 收敛阶与外推",
            "",
            f"根据中网格和细网格结果估计的观测收敛阶为 {order:.4f}。",
            f"Richardson 外推烘干时间为 {richardson:.6f} h。",
            f"细网格结果与外推值的差为 {abs(fine - richardson):.6f} h。",
            "",
            "## 结论",
            "",
            "需要结合三组结果是否单调以及差值是否随网格加密缩小来判断网格收敛性。若 Richardson 外推值与细网格结果接近，则细网格结果可作为最终结果。",
        ]
    )
    markdown_path = BASE_DIR / "第三问网格收敛检验.md"
    markdown_path.write_text("\n".join(lines), encoding="utf-8")

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "网格收敛"
    worksheet.append(
        [
            "网格",
            "径向单元",
            "轴向单元",
            "节点数",
            "时间步长/s",
            "烘干时间/h",
            "最终最大含水率",
            "平均迭代次数",
            "计算耗时/s",
        ]
    )
    for record in records:
        worksheet.append(
            [
                record["name"],
                record["n_radial"],
                record["n_axial"],
                record["nodes"],
                record["dt"],
                record["dry_hours"],
                record["final_max"],
                record["iterations"],
                record["elapsed"],
            ]
        )
    worksheet.append([])
    worksheet.append(["观测收敛阶", order])
    worksheet.append(["Richardson 外推/h", richardson])
    worksheet.append(["细网格与外推之差/h", abs(fine - richardson)])

    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, float):
                cell.number_format = "0.000000"
    for column_cells in worksheet.columns:
        width = max(
            len(str(cell.value)) if cell.value is not None else 0
            for cell in column_cells
        )
        worksheet.column_dimensions[
            column_cells[0].column_letter
        ].width = min(max(width + 2, 12), 26)

    workbook_path = BASE_DIR / "第三问网格收敛检验.xlsx"
    workbook.save(workbook_path)

    np.savez_compressed(
        BASE_DIR / "q3_grid_convergence.npz",
        levels=np.array([record["nodes"] for record in records]),
        dry_hours=np.array(
            [record["dry_hours"] for record in records]
        ),
        order=order,
        richardson_hours=richardson,
    )

    for record in records:
        print(
            record["name"],
            f"grid={record['n_radial']}x{record['n_axial']}",
            f"dry={record['dry_hours']:.6f} h",
            f"elapsed={record['elapsed']:.2f} s",
        )
    print(f"observed order: {order:.6f}")
    print(f"Richardson dry time: {richardson:.6f} h")
    print(f"markdown: {markdown_path}")
    print(f"workbook: {workbook_path}")


if __name__ == "__main__":
    main()
