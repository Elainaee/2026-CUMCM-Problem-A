"""Uniform steady-state test for the conservative finite-volume solver."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from openpyxl import Workbook

import q2_2d_model as base
import q3_2d_model as q3


BASE_DIR = Path(__file__).resolve().parent
UNIFORM_TEMPERATURE = 50.0
UNIFORM_MOISTURE = 0.05
TEST_DURATION = 24 * 3600


def main() -> None:
    radii = np.linspace(0.0, base.RADIUS, q3.N_RADIAL + 1)
    axial_positions = np.linspace(
        0.0, base.LENGTH, q3.N_AXIAL + 1
    )
    dr = base.RADIUS / q3.N_RADIAL
    dz = base.LENGTH / q3.N_AXIAL
    node_count = (q3.N_RADIAL + 1) * (q3.N_AXIAL + 1)

    state = np.concatenate(
        (
            np.full(node_count, UNIFORM_TEMPERATURE),
            np.full(node_count, UNIFORM_MOISTURE),
        )
    )
    original_temperature = base.air_temperature
    original_moisture = base.air_moisture
    base.air_temperature = lambda _: UNIFORM_TEMPERATURE
    base.air_moisture = lambda _: UNIFORM_MOISTURE

    try:
        initial_rhs = base.right_hand_side(
            state, 0.0, q3.N_RADIAL, q3.N_AXIAL, dr, dz
        )
        initial_max_rhs = float(np.max(np.abs(initial_rhs)))

        step_count = int(round(TEST_DURATION / q3.DT))
        for _ in range(step_count):
            state, _ = q3.implicit_rk4_step(
                state, 0.0, dr, dz
            )
    finally:
        base.air_temperature = original_temperature
        base.air_moisture = original_moisture

    temperature = state[:node_count].reshape(
        q3.N_RADIAL + 1, q3.N_AXIAL + 1
    )
    concentration = state[node_count:].reshape(
        q3.N_RADIAL + 1, q3.N_AXIAL + 1
    )
    maximum_temperature_drift = float(
        np.max(np.abs(temperature - UNIFORM_TEMPERATURE))
    )
    maximum_moisture_drift = float(
        np.max(np.abs(concentration - UNIFORM_MOISTURE))
    )

    lines = [
        "# 第三问均匀稳态检验",
        "",
        "## 测试设置",
        "",
        f"初始和边界温度均设为 {UNIFORM_TEMPERATURE:.2f} °C，",
        f"初始和边界水分浓度均设为 {UNIFORM_MOISTURE:.2f} kg/kg。",
        "",
        f"使用当前守恒有限体积格式和隐式 RK4 连续计算 {TEST_DURATION / 3600:.0f} h。",
        "",
        "## 检验结果",
        "",
        f"- 初始右端项最大绝对量：{initial_max_rhs:.6e}",
        f"- 24 h 后最大温度漂移：{maximum_temperature_drift:.6e} °C",
        f"- 24 h 后最大水分浓度漂移：{maximum_moisture_drift:.6e} kg/kg",
        "",
        "## 判定",
        "",
        "均匀场在均匀边界下应始终保持不变。若漂移量接近机器精度，说明控制体体积、内部面通量和表面边界通量在稳态下相互抵消。",
    ]
    report_path = BASE_DIR / "第三问均匀稳态检验.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "均匀稳态检验"
    worksheet.append(["项目", "数值"])
    worksheet.append(["初始右端项最大绝对量", initial_max_rhs])
    worksheet.append(["24 h 最大温度漂移/°C", maximum_temperature_drift])
    worksheet.append(
        ["24 h 最大水分浓度漂移", maximum_moisture_drift]
    )
    workbook_path = BASE_DIR / "第三问均匀稳态检验.xlsx"
    workbook.save(workbook_path)

    np.savez_compressed(
        BASE_DIR / "q3_uniform_steady_test.npz",
        initial_max_rhs=initial_max_rhs,
        maximum_temperature_drift=maximum_temperature_drift,
        maximum_moisture_drift=maximum_moisture_drift,
        uniform_temperature=UNIFORM_TEMPERATURE,
        uniform_moisture=UNIFORM_MOISTURE,
        duration_s=TEST_DURATION,
    )

    print(f"initial RHS max: {initial_max_rhs:.6e}")
    print(
        f"24 h temperature drift: {maximum_temperature_drift:.6e} °C"
    )
    print(
        f"24 h moisture drift: {maximum_moisture_drift:.6e} kg/kg"
    )
    print(f"report: {report_path}")
    print(f"workbook: {workbook_path}")


if __name__ == "__main__":
    main()
