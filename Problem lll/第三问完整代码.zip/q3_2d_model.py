"""Question 3: 2D axisymmetric drying until all moisture is below 0.15."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from openpyxl import load_workbook

import q2_2d_model as base


BASE_DIR = Path(__file__).resolve().parent
CRITICAL_TIME = base.CRITICAL_TIME
PHASE_TRANSITION_START = CRITICAL_TIME - base.PHASE_TRANSITION_DURATION
PHASE_TRANSITION_END = CRITICAL_TIME
THRESHOLD = 0.15
DT = 2.5
RECORD_INTERVAL = 60.0
MAX_DURATION = 10 * 24 * 3600
N_RADIAL = 24
N_AXIAL = 50
TABLE_INTERVAL = 6 * 3600
TABLE_RADII_CM = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
IMPLICIT_TOLERANCE = 1.0e-7
IMPLICIT_MAX_ITERATIONS = 20
IMPLICIT_RELAXATION = 0.8

SQRT_THREE = np.sqrt(3.0)
RK4_C = np.array(
    [0.5 - SQRT_THREE / 6.0, 0.5 + SQRT_THREE / 6.0]
)
RK4_A = np.array(
    [
        [0.25, 0.25 - SQRT_THREE / 6.0],
        [0.25 + SQRT_THREE / 6.0, 0.25],
    ]
)
RK4_B = np.array([0.5, 0.5])


def make_state(n_radial: int, n_axial: int) -> np.ndarray:
    node_count = (n_radial + 1) * (n_axial + 1)
    return np.concatenate(
        (
            np.full(node_count, base.TEMPERATURE_0),
            np.full(node_count, base.MOISTURE_0),
        )
    )


def profiles_from_state(
    state: np.ndarray,
    output_radii: np.ndarray,
    radii: np.ndarray,
    axial_positions: np.ndarray,
    n_radial: int,
    n_axial: int,
) -> tuple[np.ndarray, np.ndarray]:
    node_count = (n_radial + 1) * (n_axial + 1)
    temperature = state[:node_count].reshape(n_radial + 1, n_axial + 1)
    concentration = state[node_count:].reshape(
        n_radial + 1, n_axial + 1
    )
    averaged_temperature = (
        np.trapezoid(temperature, axial_positions, axis=1) / base.LENGTH
    )
    averaged_concentration = (
        np.trapezoid(concentration, axial_positions, axis=1) / base.LENGTH
    )
    return (
        np.interp(output_radii, radii, averaged_temperature),
        np.interp(output_radii, radii, averaged_concentration),
    )


def implicit_rk4_step(
    state: np.ndarray,
    time: float,
    dr: float,
    dz: float,
) -> tuple[np.ndarray, int]:
    """Advance one step with the two-stage Gauss-Legendre implicit RK4."""
    stage_1 = state.copy()
    stage_2 = state.copy()

    for iteration in range(1, IMPLICIT_MAX_ITERATIONS + 1):
        derivative_1 = base.right_hand_side(
            stage_1,
            time + RK4_C[0] * DT,
            N_RADIAL,
            N_AXIAL,
            dr,
            dz,
        )
        derivative_2 = base.right_hand_side(
            stage_2,
            time + RK4_C[1] * DT,
            N_RADIAL,
            N_AXIAL,
            dr,
            dz,
        )
        next_stage_1 = state + DT * (
            RK4_A[0, 0] * derivative_1
            + RK4_A[0, 1] * derivative_2
        )
        next_stage_2 = state + DT * (
            RK4_A[1, 0] * derivative_1
            + RK4_A[1, 1] * derivative_2
        )
        error = max(
            float(np.max(np.abs(next_stage_1 - stage_1))),
            float(np.max(np.abs(next_stage_2 - stage_2))),
        )
        stage_1 = (
            (1.0 - IMPLICIT_RELAXATION) * stage_1
            + IMPLICIT_RELAXATION * next_stage_1
        )
        stage_2 = (
            (1.0 - IMPLICIT_RELAXATION) * stage_2
            + IMPLICIT_RELAXATION * next_stage_2
        )
        if error < IMPLICIT_TOLERANCE:
            break
    else:
        raise RuntimeError(
            "Implicit RK4 fixed-point iteration did not converge"
        )

    derivative_1 = base.right_hand_side(
        stage_1,
        time + RK4_C[0] * DT,
        N_RADIAL,
        N_AXIAL,
        dr,
        dz,
    )
    derivative_2 = base.right_hand_side(
        stage_2,
        time + RK4_C[1] * DT,
        N_RADIAL,
        N_AXIAL,
        dr,
        dz,
    )
    next_state = state + DT * (
        RK4_B[0] * derivative_1 + RK4_B[1] * derivative_2
    )
    return next_state, iteration


def simulate() -> dict[str, object]:
    radii = np.linspace(0.0, base.RADIUS, N_RADIAL + 1)
    axial_positions = np.linspace(0.0, base.LENGTH, N_AXIAL + 1)
    output_radii = base.OUTPUT_RADII
    dr = base.RADIUS / N_RADIAL
    dz = base.LENGTH / N_AXIAL

    state = make_state(N_RADIAL, N_AXIAL)
    recorded_times = [0.0]
    recorded_temperature = []
    recorded_concentration = []
    temperature_profile, concentration_profile = profiles_from_state(
        state,
        output_radii,
        radii,
        axial_positions,
        N_RADIAL,
        N_AXIAL,
    )
    recorded_temperature.append(temperature_profile)
    recorded_concentration.append(concentration_profile)

    time = 0.0
    previous_time = 0.0
    previous_state = state.copy()
    previous_max_concentration = float(state[-len(state) // 2 :].max())
    steps_per_record = int(round(RECORD_INTERVAL / DT))
    step = 0
    final_state = state
    final_time = 0.0
    iteration_total = 0
    completed_steps = 0

    while time < MAX_DURATION:
        previous_time = time
        previous_state = state.copy()
        state, iterations = implicit_rk4_step(state, time, dr, dz)
        iteration_total += iterations
        completed_steps += 1
        time += DT
        step += 1
        current_max_concentration = float(state[
            (N_RADIAL + 1) * (N_AXIAL + 1) :
        ].max())

        if step % steps_per_record == 0:
            temperature_profile, concentration_profile = (
                profiles_from_state(
                    state,
                    output_radii,
                    radii,
                    axial_positions,
                    N_RADIAL,
                    N_AXIAL,
                )
            )
            recorded_times.append(time)
            recorded_temperature.append(temperature_profile)
            recorded_concentration.append(concentration_profile)

        if current_max_concentration <= THRESHOLD:
            denominator = (
                previous_max_concentration - current_max_concentration
            )
            if abs(denominator) < 1.0e-15:
                fraction = 0.0
            else:
                fraction = (
                    previous_max_concentration - THRESHOLD
                ) / denominator
            fraction = float(np.clip(fraction, 0.0, 1.0))
            final_state = (
                (1.0 - fraction) * previous_state
                + fraction * state
            )
            final_time = previous_time + fraction * DT
            temperature_profile, concentration_profile = (
                profiles_from_state(
                    final_state,
                    output_radii,
                    radii,
                    axial_positions,
                    N_RADIAL,
                    N_AXIAL,
                )
            )
            if final_time - recorded_times[-1] > 1.0e-9:
                recorded_times.append(final_time)
                recorded_temperature.append(temperature_profile)
                recorded_concentration.append(concentration_profile)
            break

        previous_max_concentration = current_max_concentration

    return {
        "time_s": np.asarray(recorded_times),
        "radius_cm": output_radii * 100.0,
        "temperature_c": np.asarray(recorded_temperature),
        "moisture_kg_per_kg": np.asarray(recorded_concentration),
        "final_time_s": final_time,
        "final_state": final_state,
        "radii": radii,
        "axial_positions": axial_positions,
        "n_radial": N_RADIAL,
        "n_axial": N_AXIAL,
        "average_iterations": iteration_total / max(completed_steps, 1),
    }


def write_result_workbook(
    times: np.ndarray, concentrations: np.ndarray
) -> Path:
    template_path = BASE_DIR / "附件" / "附件3" / "result3.xlsx"
    output_path = BASE_DIR / "result3.xlsx"
    workbook = load_workbook(template_path)
    worksheet = workbook["Sheet1"]
    worksheet.delete_rows(2, worksheet.max_row)

    headers = ["时间\\到药材中心的距离"] + [
        float(f"{radius:.1f}") for radius in base.OUTPUT_RADII * 100.0
    ]
    for column, value in enumerate(headers, start=1):
        cell = worksheet.cell(row=1, column=column, value=value)
        cell.number_format = "0.0"

    for row_index, (time, profile) in enumerate(
        zip(times, concentrations), start=2
    ):
        time_cell = worksheet.cell(
            row=row_index, column=1, value=float(round(time, 3))
        )
        time_cell.number_format = "0"
        for column, value in enumerate(profile, start=2):
            cell = worksheet.cell(
                row=row_index,
                column=column,
                value=float(round(value, 4)),
            )
            cell.number_format = "0.0000"

    workbook.save(output_path)
    workbook.close()
    return output_path


def main() -> None:
    result = simulate()
    times = result["time_s"]
    concentrations = result["moisture_kg_per_kg"]
    temperatures = result["temperature_c"]
    output_path = write_result_workbook(times, concentrations)

    np.savez_compressed(
        BASE_DIR / "q3_2d_results.npz",
        time_s=times,
        radius_cm=result["radius_cm"],
        temperature_c=temperatures,
        moisture_kg_per_kg=concentrations,
        final_time_s=result["final_time_s"],
        final_state=result["final_state"],
        average_iterations=result["average_iterations"],
    )

    table_indices = [
        int(np.argmin(np.abs(result["radius_cm"] - radius)))
        for radius in TABLE_RADII_CM
    ]
    table_rows = []
    for table_time in np.arange(
        TABLE_INTERVAL, times[-1], TABLE_INTERVAL
    ):
        index = int(np.argmin(np.abs(times - table_time)))
        table_rows.append(
            (
                times[index] / 3600.0,
                concentrations[index, table_indices],
            )
        )
    table_rows.append(
        (
            times[-1] / 3600.0,
            concentrations[-1, table_indices],
        )
    )

    lines = [
        "# 第三问二维模型结果",
        "",
        "## 计算设置",
        "",
        "二维轴对称模型，预热阶段使用第一问参数，随后按附件 1 温度数据驱动的权重连续过渡到附录 3 经验公式。",
        "",
        f"由尾部平台中位数、MAD、20 min 滑动均值和斜率条件识别得到临界时刻 t_c={CRITICAL_TIME:.0f} s，平滑过渡区间为 {PHASE_TRANSITION_START:.0f}–{PHASE_TRANSITION_END:.0f} s。",
        "",
        f"含水率阈值为 {THRESHOLD:.2f} kg/kg，径向网格节点数为 {N_RADIAL + 1}，轴向网格节点数为 {N_AXIAL + 1}，时间步长为 {DT:.1f} s。",
        "",
        "时间推进采用二阶段 Gauss-Legendre 隐式 RK4，并通过固定点迭代求解隐式阶段方程。",
        "",
        "## 烘干时间",
        "",
        f"满足全药材含水率低于 {THRESHOLD:.2f} kg/kg 的时间为 {times[-1] / 3600.0:.4f} h。",
        "",
        f"最终最大含水率为 {concentrations[-1].max():.6f} kg/kg。",
        "",
        "## 每 6 h 的轴向平均含水率",
        "",
        "| 时间/h | r=0 cm | r=0.5 cm | r=1.0 cm | r=1.5 cm | r=2.0 cm |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for time_h, profile in table_rows:
        lines.append(
            f"| {time_h:.4f} | "
            + " | ".join(f"{value:.4f}" for value in profile)
            + " |"
        )
    lines.extend(
        [
            "",
            "## 文件",
            "",
            "- `q3_2d_model.py`：第三问二维长时求解代码；",
            "- `result3.xlsx`：每 60 s 的径向水分浓度；",
            "- `q3_2d_results.npz`：完整数值结果。",
            "",
            "## 模型问题与限制",
            "",
            "- 时间推进采用二阶段 Gauss-Legendre 隐式 RK4，时间步长为 2.5 s。",
            "- 守恒有限体积格式下，三种空间网格给出的烘干时间分别约为 55.765 h、56.413 h 和 56.757 h，Richardson 外推约为 57.145 h。生产网格结果 56.933 h 与细网格外推值相差约 0.212 h。",
            "- 过渡阶段表面水分浓度存在局部回升，最大约 0.015 kg/kg。该现象在径向加密后仍存在，主要来自温度升高后内部水分向表面输送速率增加；论文中应将其解释为过渡阶段的内部水分再分布，或通过延长物性过渡进一步考查。",
            "- 附件 1 结束后采用平台环境值 T_inf=49.97 °C、C_inf=0.0499 kg/kg，并保持至干燥结束。",
            "- 全局水分守恒检验的归一化相对误差约为 3.64e-5，说明控制体水分变化与所有表面累计传质通量实现了闭合。",
        ]
    )
    report_path = BASE_DIR / "第三问二维模型结果.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    print(f"dry time: {times[-1] / 3600.0:.6f} h")
    print(f"final max moisture: {concentrations[-1].max():.6f}")
    print(f"average implicit iterations: {result['average_iterations']:.3f}")
    print(f"result workbook: {output_path}")
    print(f"report: {report_path}")


if __name__ == "__main__":
    main()
