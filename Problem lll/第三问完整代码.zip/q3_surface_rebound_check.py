"""Grid study of the temporary surface-moisture rebound."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

import q3_2d_model as model


BASE_DIR = Path(__file__).resolve().parent
TEST_DURATION = 2 * 3600
GRID_LEVELS = [
    ("粗网格", 10, 20),
    ("中网格", 15, 30),
    ("细网格", 20, 40),
]
HEADER_FILL = PatternFill("solid", fgColor="D9EAF7")


def run_case(
    name: str, n_radial: int, n_axial: int
) -> dict[str, object]:
    original = (
        model.N_RADIAL,
        model.N_AXIAL,
        model.DT,
        model.MAX_DURATION,
        model.THRESHOLD,
    )
    model.N_RADIAL = n_radial
    model.N_AXIAL = n_axial
    model.DT = 2.5
    model.MAX_DURATION = TEST_DURATION
    model.THRESHOLD = -1.0
    try:
        result = model.simulate()
    finally:
        (
            model.N_RADIAL,
            model.N_AXIAL,
            model.DT,
            model.MAX_DURATION,
            model.THRESHOLD,
        ) = original

    times = result["time_s"]
    surface = result["moisture_kg_per_kg"][:, -1]
    differences = np.diff(surface)
    maximum_increase_index = int(np.argmax(differences))
    return {
        "name": name,
        "n_radial": n_radial,
        "n_axial": n_axial,
        "maximum_rebound": float(differences[maximum_increase_index]),
        "rebound_time": float(times[maximum_increase_index]),
        "surface_at_rebound": float(
            surface[maximum_increase_index]
        ),
        "surface_final": float(surface[-1]),
    }


def main() -> None:
    results = [
        run_case(name, n_radial, n_axial)
        for name, n_radial, n_axial in GRID_LEVELS
    ]

    lines = [
        "# 过渡阶段表面含水率回升检验",
        "",
        "## 目的",
        "",
        "检查 0–2 h 过渡阶段中表面含水率局部回升是否主要由空间离散误差造成。",
        "",
        "## 网格结果",
        "",
        "| 网格 | 径向单元 | 轴向单元 | 最大回升量/(kg/kg) | 回升发生时间/s |",
        "|---|---:|---:|---:|---:|",
    ]
    for result in results:
        lines.append(
            f"| {result['name']} | {result['n_radial']} | "
            f"{result['n_axial']} | "
            f"{result['maximum_rebound']:.6f} | "
            f"{result['rebound_time']:.1f} |"
        )
    lines.extend(
        [
            "",
            "## 判定",
            "",
            "若回升量随网格加密明显减小，则该现象主要具有离散误差特征。",
            "若回升量在不同网格下保持相近，则说明它是当前连续模型中的水分再分布现象，应通过物性变化和边界通量解释。",
        ]
    )
    report_path = BASE_DIR / "第三问表面含水率回升检验.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "表面回升检验"
    worksheet.append(
        [
            "网格",
            "径向单元",
            "轴向单元",
            "最大回升量",
            "回升时间/s",
            "回升时表面含水率",
            "2h表面含水率",
        ]
    )
    for result in results:
        worksheet.append(
            [
                result["name"],
                result["n_radial"],
                result["n_axial"],
                result["maximum_rebound"],
                result["rebound_time"],
                result["surface_at_rebound"],
                result["surface_final"],
            ]
        )
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = HEADER_FILL
    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, float):
                cell.number_format = "0.000000"
    workbook_path = BASE_DIR / "第三问表面含水率回升检验.xlsx"
    workbook.save(workbook_path)

    np.savez_compressed(
        BASE_DIR / "q3_surface_rebound_check.npz",
        grid_radial=np.array(
            [result["n_radial"] for result in results]
        ),
        grid_axial=np.array(
            [result["n_axial"] for result in results]
        ),
        maximum_rebound=np.array(
            [result["maximum_rebound"] for result in results]
        ),
        rebound_time=np.array(
            [result["rebound_time"] for result in results]
        ),
    )

    for result in results:
        print(
            result["name"],
            f"rebound={result['maximum_rebound']:.6f}",
            f"time={result['rebound_time']:.1f} s",
        )
    print(f"report: {report_path}")
    print(f"workbook: {workbook_path}")


if __name__ == "__main__":
    main()
