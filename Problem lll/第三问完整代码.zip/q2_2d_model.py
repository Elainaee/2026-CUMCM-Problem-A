"""Question 2: 2D axisymmetric drying model over the first three hours."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np
from openpyxl import load_workbook


BASE_DIR = Path(__file__).resolve().parent

RADIUS = 0.02
LENGTH = 0.25
TEMPERATURE_0 = 28.0
MOISTURE_0 = 2.55

HEAT_TRANSFER_COEFFICIENT = 25.0
MASS_TRANSFER_COEFFICIENT = 8.0e-7

DRYING_AIR_TEMPERATURE = 49.97
DRYING_AIR_MOISTURE = 0.0499
PLATEAU_START_TIME = 10800.0
CRITICAL_WINDOW = 1200.0
CRITICAL_PERSISTENCE = 1800.0
PHASE_TRANSITION_DURATION = 1800.0

OUTPUT_RADII = np.arange(0.0, RADIUS + 0.0005, 0.001)
FULL_FIELD_TIMES = np.array([0, 1800, 3600, 5400, 7200, 9000, 10800])
TABLE_TIMES = np.array([1800, 3600, 5400, 7200, 9000, 10800])


def read_boundary_conditions() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    path = BASE_DIR / "附件" / "附件1.xlsx"
    workbook = load_workbook(path, data_only=True, read_only=True)
    worksheet = workbook.active
    rows = [
        (float(row[0]), float(row[1]), float(row[2]))
        for row in worksheet.iter_rows(min_row=2, values_only=True)
        if row[0] is not None
    ]
    workbook.close()
    values = np.asarray(rows, dtype=float)
    return values[:, 0], values[:, 1], values[:, 2]


BOUNDARY_TIME, BOUNDARY_TEMPERATURE, BOUNDARY_MOISTURE = (
    read_boundary_conditions()
)


def detect_critical_time() -> float:
    tail_mask = BOUNDARY_TIME >= PLATEAU_START_TIME
    tail_temperature = BOUNDARY_TEMPERATURE[tail_mask]
    plateau_temperature = float(np.median(tail_temperature))
    robust_sigma = float(
        1.4826
        * np.median(
            np.abs(tail_temperature - plateau_temperature)
        )
    )
    slope_limit = 3.0 * robust_sigma / 20.0

    def satisfies(candidate_index: int) -> bool:
        end_time = BOUNDARY_TIME[candidate_index]
        mask = (
            (BOUNDARY_TIME >= end_time - CRITICAL_WINDOW)
            & (BOUNDARY_TIME <= end_time)
        )
        if np.count_nonzero(mask) < 5:
            return False
        window_time_minutes = BOUNDARY_TIME[mask] / 60.0
        window_temperature = BOUNDARY_TEMPERATURE[mask]
        mean_temperature = float(np.mean(window_temperature))
        slope = float(
            np.polyfit(
                window_time_minutes, window_temperature, 1
            )[0]
        )
        return (
            abs(mean_temperature - plateau_temperature)
            <= 2.0 * robust_sigma
            and abs(slope) <= slope_limit
        )

    for candidate_index, candidate_time in enumerate(BOUNDARY_TIME):
        if candidate_time < CRITICAL_WINDOW:
            continue
        if not satisfies(candidate_index):
            continue
        persistent = True
        persistence_end = candidate_time + CRITICAL_PERSISTENCE
        for check_index in range(candidate_index, len(BOUNDARY_TIME)):
            if BOUNDARY_TIME[check_index] > persistence_end:
                break
            if not satisfies(check_index):
                persistent = False
                break
        if persistent:
            return float(candidate_time)
    raise RuntimeError("Could not determine the phase-switch time")


CRITICAL_TIME = detect_critical_time()


def build_phase_weight() -> np.ndarray:
    transition_start = CRITICAL_TIME - PHASE_TRANSITION_DURATION
    scaled = np.clip(
        (BOUNDARY_TIME - transition_start)
        / PHASE_TRANSITION_DURATION,
        0.0,
        1.0,
    )
    return scaled * scaled * (3.0 - 2.0 * scaled)


PHASE_WEIGHT = build_phase_weight()


def air_temperature(time: float) -> float:
    attachment_value = raw_air_temperature(time)
    weight = phase_weight(time)
    return (1.0 - weight) * attachment_value + weight * DRYING_AIR_TEMPERATURE


def air_moisture(time: float) -> float:
    attachment_value = float(
        np.interp(time, BOUNDARY_TIME, BOUNDARY_MOISTURE)
    )
    weight = phase_weight(time)
    return (1.0 - weight) * attachment_value + weight * DRYING_AIR_MOISTURE


def raw_air_temperature(time: float) -> float:
    return float(np.interp(time, BOUNDARY_TIME, BOUNDARY_TEMPERATURE))


def phase_weight(time: float) -> float:
    return float(np.interp(time, BOUNDARY_TIME, PHASE_WEIGHT))


def moisture_diffusivity(
    concentration: np.ndarray,
    temperature_c: np.ndarray,
    time: float,
) -> np.ndarray:
    concentration = np.maximum(concentration, 1.0e-9)
    first_phase = 7.0e-9 * np.exp(-0.89 / concentration)
    temperature_k = np.maximum(temperature_c + 273.15, 1.0)
    second_phase = (
        2.4e-3
        * np.exp(-0.45 / concentration)
        * np.exp(-3850.0 / temperature_k)
    )
    weight = phase_weight(time)
    return (1.0 - weight) * first_phase + weight * second_phase


def material_properties(
    concentration: np.ndarray,
    time: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    first_density = np.full_like(concentration, 820.0)
    first_heat_capacity = np.full_like(concentration, 2600.0)
    first_conductivity = np.full_like(concentration, 0.36)
    ratio = concentration / (concentration + 1.0)
    second_density = 650.0 + 128.0 * concentration
    second_heat_capacity = 1450.0 + 2736.0 * ratio
    second_conductivity = 0.21 + 0.38 * ratio
    weight = phase_weight(time)
    return (
        (1.0 - weight) * first_density + weight * second_density,
        (1.0 - weight) * first_heat_capacity
        + weight * second_heat_capacity,
        (1.0 - weight) * first_conductivity
        + weight * second_conductivity,
    )


@lru_cache(maxsize=None)
def make_geometry(
    n_radial: int, n_axial: int
) -> tuple[
    float,
    float,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    """Build axisymmetric control-volume areas and volumes."""
    radii = np.linspace(0.0, RADIUS, n_radial + 1)
    axial_positions = np.linspace(0.0, LENGTH, n_axial + 1)
    dr = RADIUS / n_radial
    dz = LENGTH / n_axial

    radial_left = np.empty(n_radial + 1)
    radial_right = np.empty(n_radial + 1)
    radial_left[0] = 0.0
    radial_right[0] = 0.5 * (radii[0] + radii[1])
    radial_left[-1] = 0.5 * (radii[-2] + radii[-1])
    radial_right[-1] = RADIUS
    if n_radial > 1:
        radial_left[1:-1] = 0.5 * (radii[:-2] + radii[1:-1])
        radial_right[1:-1] = 0.5 * (radii[1:-1] + radii[2:])

    axial_left = np.empty(n_axial + 1)
    axial_right = np.empty(n_axial + 1)
    axial_left[0] = 0.0
    axial_right[0] = 0.5 * (
        axial_positions[0] + axial_positions[1]
    )
    axial_left[-1] = 0.5 * (
        axial_positions[-2] + axial_positions[-1]
    )
    axial_right[-1] = LENGTH
    if n_axial > 1:
        axial_left[1:-1] = 0.5 * (
            axial_positions[:-2] + axial_positions[1:-1]
        )
        axial_right[1:-1] = 0.5 * (
            axial_positions[1:-1] + axial_positions[2:]
        )

    radial_cell_area = 0.5 * (
        radial_right**2 - radial_left**2
    )
    axial_width = axial_right - axial_left
    volumes = radial_cell_area[:, None] * axial_width[None, :]

    radial_face_position = 0.5 * (radii[:-1] + radii[1:])
    radial_face_area = (
        radial_face_position[:, None] * axial_width[None, :]
    )
    axial_face_area = np.repeat(
        radial_cell_area[:, None], n_axial, axis=1
    )
    radial_boundary_area = RADIUS * axial_width
    axial_boundary_area = radial_cell_area
    return (
        dr,
        dz,
        volumes,
        radial_face_area,
        axial_face_area,
        radial_boundary_area,
        axial_boundary_area,
    )


def conservative_operator(
    values: np.ndarray,
    transport_property: np.ndarray,
    boundary_coefficient: float,
    ambient_value: float,
    geometry: tuple,
) -> np.ndarray:
    """Conservative axisymmetric divergence of a diffusive flux."""
    (
        dr,
        dz,
        volumes,
        radial_face_area,
        axial_face_area,
        radial_boundary_area,
        axial_boundary_area,
    ) = geometry
    result = np.zeros_like(values)

    radial_diffusivity = 0.5 * (
        transport_property[:-1] + transport_property[1:]
    )
    radial_flux = (
        radial_face_area
        * radial_diffusivity
        * (values[1:] - values[:-1])
        / dr
    )
    result[:-1] += radial_flux
    result[1:] -= radial_flux

    axial_diffusivity = 0.5 * (
        transport_property[:, :-1] + transport_property[:, 1:]
    )
    axial_flux = (
        axial_face_area
        * axial_diffusivity
        * (values[:, 1:] - values[:, :-1])
        / dz
    )
    result[:, :-1] += axial_flux
    result[:, 1:] -= axial_flux
    result /= volumes

    result[-1] -= (
        radial_boundary_area
        * boundary_coefficient
        * (values[-1] - ambient_value)
        / volumes[-1]
    )
    result[:, 0] -= (
        axial_boundary_area
        * boundary_coefficient
        * (values[:, 0] - ambient_value)
        / volumes[:, 0]
    )
    result[:, -1] -= (
        axial_boundary_area
        * boundary_coefficient
        * (values[:, -1] - ambient_value)
        / volumes[:, -1]
    )
    return result


def right_hand_side(
    state: np.ndarray,
    time: float,
    n_radial: int,
    n_axial: int,
    dr: float,
    dz: float,
) -> np.ndarray:
    node_count = (n_radial + 1) * (n_axial + 1)
    temperature = state[:node_count].reshape(n_radial + 1, n_axial + 1)
    concentration = state[node_count:].reshape(
        n_radial + 1, n_axial + 1
    )

    air_temperature_value = air_temperature(time)
    air_moisture_value = air_moisture(time)
    density, heat_capacity, conductivity = material_properties(
        concentration, time
    )
    diffusivity = moisture_diffusivity(concentration, temperature, time)
    geometry = make_geometry(n_radial, n_axial)

    thermal_flux = conservative_operator(
        temperature,
        conductivity,
        HEAT_TRANSFER_COEFFICIENT,
        air_temperature_value,
        geometry,
    )
    d_temperature = thermal_flux / (density * heat_capacity)

    d_concentration = conservative_operator(
        concentration,
        diffusivity,
        MASS_TRANSFER_COEFFICIENT,
        air_moisture_value,
        geometry,
    )

    return np.concatenate(
        (d_temperature.ravel(), d_concentration.ravel())
    )


def interpolate_to_output_radii(
    radii: np.ndarray, profile: np.ndarray
) -> np.ndarray:
    return np.interp(OUTPUT_RADII, radii, profile)


def simulate(
    dt: float,
    n_radial: int,
    n_axial: int,
    duration: int = 10800,
    save_full_times: np.ndarray | None = None,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    radii = np.linspace(0.0, RADIUS, n_radial + 1)
    axial_positions = np.linspace(0.0, LENGTH, n_axial + 1)
    dr = RADIUS / n_radial
    dz = LENGTH / n_axial
    middle = np.argmin(np.abs(axial_positions - 0.5 * LENGTH))

    node_count = (n_radial + 1) * (n_axial + 1)
    state = np.concatenate(
        (
            np.full(node_count, TEMPERATURE_0),
            np.full(node_count, MOISTURE_0),
        )
    )

    steps_per_second = int(round(1.0 / dt))
    if not np.isclose(steps_per_second * dt, 1.0):
        raise ValueError("dt must divide one second exactly")

    if save_full_times is None:
        save_full_times = np.array([0, duration], dtype=int)
    save_full_times = np.unique(np.asarray(save_full_times, dtype=int))
    if np.any((save_full_times < 0) | (save_full_times > duration)):
        raise ValueError("save_full_times must lie within the simulation")
    full_index = {
        int(time): index for index, time in enumerate(save_full_times)
    }

    average_temperature = np.empty((duration + 1, OUTPUT_RADII.size))
    average_concentration = np.empty((duration + 1, OUTPUT_RADII.size))
    midplane_temperature = np.empty((duration + 1, OUTPUT_RADII.size))
    midplane_concentration = np.empty((duration + 1, OUTPUT_RADII.size))
    full_temperature = np.empty(
        (save_full_times.size, n_radial + 1, n_axial + 1)
    )
    full_concentration = np.empty(
        (save_full_times.size, n_radial + 1, n_axial + 1)
    )

    def record(second: int) -> None:
        temperature = state[:node_count].reshape(
            n_radial + 1, n_axial + 1
        )
        concentration = state[node_count:].reshape(
            n_radial + 1, n_axial + 1
        )
        averaged_temperature = (
            np.trapezoid(temperature, axial_positions, axis=1) / LENGTH
        )
        averaged_concentration = (
            np.trapezoid(concentration, axial_positions, axis=1) / LENGTH
        )
        average_temperature[second] = interpolate_to_output_radii(
            radii, averaged_temperature
        )
        average_concentration[second] = interpolate_to_output_radii(
            radii, averaged_concentration
        )
        midplane_temperature[second] = interpolate_to_output_radii(
            radii, temperature[:, middle]
        )
        midplane_concentration[second] = interpolate_to_output_radii(
            radii, concentration[:, middle]
        )
        if second in full_index:
            full_temperature[full_index[second]] = temperature
            full_concentration[full_index[second]] = concentration

    record(0)
    step = 0
    for second in range(duration):
        for _ in range(steps_per_second):
            time = step * dt
            k1 = right_hand_side(
                state, time, n_radial, n_axial, dr, dz
            )
            k2 = right_hand_side(
                state + 0.5 * dt * k1,
                time + 0.5 * dt,
                n_radial,
                n_axial,
                dr,
                dz,
            )
            k3 = right_hand_side(
                state + 0.5 * dt * k2,
                time + 0.5 * dt,
                n_radial,
                n_axial,
                dr,
                dz,
            )
            k4 = right_hand_side(
                state + dt * k3,
                time + dt,
                n_radial,
                n_axial,
                dr,
                dz,
            )
            state += dt * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0
            step += 1
        record(second + 1)

    return (
        radii,
        axial_positions,
        average_temperature,
        average_concentration,
        midplane_temperature,
        midplane_concentration,
        full_temperature,
        full_concentration,
    )


def write_result_workbook(
    temperatures: np.ndarray,
    concentrations: np.ndarray,
) -> Path:
    template_path = BASE_DIR / "附件" / "附件3" / "result2.xlsx"
    output_path = BASE_DIR / "result2.xlsx"
    workbook = load_workbook(template_path)

    headers = ["时间\\到药材中心的距离"] + [
        float(f"{radius * 100:.1f}") for radius in OUTPUT_RADII
    ]
    for sheet_name, values in (
        ("温度", temperatures),
        ("水分浓度", concentrations),
    ):
        worksheet = workbook[sheet_name]
        worksheet.delete_rows(2, worksheet.max_row)
        for column, value in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=column, value=value)
            cell.number_format = "0.0"

        for second in range(values.shape[0]):
            time_cell = worksheet.cell(
                row=second + 2, column=1, value=second
            )
            time_cell.number_format = "0"
            for column, value in enumerate(values[second], start=2):
                cell = worksheet.cell(
                    row=second + 2,
                    column=column,
                    value=float(round(value, 4)),
                )
                cell.number_format = "0.0000"

    workbook.save(output_path)
    workbook.close()
    return output_path


def main() -> None:
    coarse = simulate(
        dt=0.2,
        n_radial=20,
        n_axial=25,
        duration=10800,
        save_full_times=FULL_FIELD_TIMES,
    )
    fine = simulate(
        dt=0.1,
        n_radial=40,
        n_axial=50,
        duration=10800,
        save_full_times=FULL_FIELD_TIMES,
    )

    coarse_average_temperature = coarse[2]
    coarse_average_concentration = coarse[3]
    coarse_midplane_temperature = coarse[4]
    coarse_midplane_concentration = coarse[5]
    fine_average_temperature = fine[2]
    fine_average_concentration = fine[3]
    fine_midplane_temperature = fine[4]
    fine_midplane_concentration = fine[5]

    average_temperature = fine_average_temperature + (
        fine_average_temperature - coarse_average_temperature
    ) / 3.0
    average_concentration = fine_average_concentration + (
        fine_average_concentration - coarse_average_concentration
    ) / 3.0
    midplane_temperature = fine_midplane_temperature + (
        fine_midplane_temperature - coarse_midplane_temperature
    ) / 3.0
    midplane_concentration = fine_midplane_concentration + (
        fine_midplane_concentration - coarse_midplane_concentration
    ) / 3.0

    output_path = write_result_workbook(
        average_temperature, average_concentration
    )
    np.savez_compressed(
        BASE_DIR / "q2_2d_results.npz",
        time_s=np.arange(average_temperature.shape[0]),
        radius_cm=OUTPUT_RADII * 100.0,
        axial_average_temperature_c=average_temperature,
        axial_average_moisture_kg_per_kg=average_concentration,
        midplane_temperature_c=midplane_temperature,
        midplane_moisture_kg_per_kg=midplane_concentration,
    )
    np.savez_compressed(
        BASE_DIR / "q2_2d_fields.npz",
        time_s=FULL_FIELD_TIMES,
        radius_cm=fine[0] * 100.0,
        axial_position_cm=fine[1] * 100.0,
        temperature_c=fine[6],
        moisture_kg_per_kg=fine[7],
    )

    print("time/s  max|dT correction|  max|dC correction|")
    for time in TABLE_TIMES:
        print(
            f"{time:6d}  "
            f"{np.max(np.abs(midplane_temperature[time] - fine_midplane_temperature[time])):18.6e}  "
            f"{np.max(np.abs(midplane_concentration[time] - fine_midplane_concentration[time])):18.6e}"
        )

    table_radii = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
    table_indices = np.searchsorted(OUTPUT_RADII * 100.0, table_radii)
    print("paper tables")
    for time in TABLE_TIMES:
        print(
            f"t={time / 3600:.1f} h  "
            f"T={average_temperature[time, table_indices]}  "
            f"C={average_concentration[time, table_indices]}"
        )
    print(f"result workbook: {output_path}")


if __name__ == "__main__":
    main()
