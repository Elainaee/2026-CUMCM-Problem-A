"""Global moisture-conservation check for the question 3 solution."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

import q2_2d_model as base
import q3_2d_model as q3


BASE_DIR = Path(__file__).resolve().parent


def moisture_content(state: np.ndarray) -> float:
    n_radial = q3.N_RADIAL
    n_axial = q3.N_AXIAL
    node_count = (n_radial + 1) * (n_axial + 1)
    concentration = state[node_count:].reshape(
        n_radial + 1, n_axial + 1
    )
    radii = np.linspace(0.0, base.RADIUS, n_radial + 1)
    axial_positions = np.linspace(0.0, base.LENGTH, n_axial + 1)
    radial_integral = np.trapezoid(
        concentration * radii[:, None], axial_positions, axis=1
    )
    return float(
        2.0
        * np.pi
        * np.trapezoid(radial_integral, radii)
    )


def surface_flux(state: np.ndarray, time: float) -> float:
    n_radial = q3.N_RADIAL
    n_axial = q3.N_AXIAL
    node_count = (n_radial + 1) * (n_axial + 1)
    concentration = state[node_count:].reshape(
        n_radial + 1, n_axial + 1
    )
    radii = np.linspace(0.0, base.RADIUS, n_radial + 1)
    axial_positions = np.linspace(0.0, base.LENGTH, n_axial + 1)
    air_moisture = base.air_moisture(time)
    hm = base.MASS_TRANSFER_COEFFICIENT

    lateral = (
        2.0
        * np.pi
        * base.RADIUS
        * hm
        * np.trapezoid(
            air_moisture - concentration[-1], axial_positions
        )
    )
    lower_end = (
        2.0
        * np.pi
        * hm
        * np.trapezoid(
            radii * (air_moisture - concentration[:, 0]), radii
        )
    )
    upper_end = (
        2.0
        * np.pi
        * hm
        * np.trapezoid(
            radii * (air_moisture - concentration[:, -1]), radii
        )
    )
    return float(lateral + lower_end + upper_end)


def main() -> None:
    radii = np.linspace(0.0, base.RADIUS, q3.N_RADIAL + 1)
    axial_positions = np.linspace(
        0.0, base.LENGTH, q3.N_AXIAL + 1
    )
    dr = base.RADIUS / q3.N_RADIAL
    dz = base.LENGTH / q3.N_AXIAL

    state = q3.make_state(q3.N_RADIAL, q3.N_AXIAL)
    initial_moisture = moisture_content(state)
    cumulative_surface_flux = 0.0
    time = 0.0
    step = 0
    final_state = state
    final_time = 0.0

    while time < q3.MAX_DURATION:
        previous_state = state.copy()
        previous_flux = surface_flux(previous_state, time)
        next_state, _ = q3.implicit_rk4_step(
            state, time, dr, dz
        )
        time += q3.DT
        next_flux = surface_flux(next_state, time)
        cumulative_surface_flux += (
            0.5 * (previous_flux + next_flux) * q3.DT
        )
        state = next_state
        step += 1

        node_count = (q3.N_RADIAL + 1) * (q3.N_AXIAL + 1)
        maximum_concentration = float(state[node_count:].max())
        if maximum_concentration <= q3.THRESHOLD:
            previous_maximum = float(previous_state[node_count:].max())
            denominator = previous_maximum - maximum_concentration
            fraction = (
                0.0
                if abs(denominator) < 1.0e-15
                else (previous_maximum - q3.THRESHOLD) / denominator
            )
            fraction = float(np.clip(fraction, 0.0, 1.0))
            final_state = (
                (1.0 - fraction) * previous_state
                + fraction * state
            )
            final_time = time - q3.DT + fraction * q3.DT
            crossing_flux = surface_flux(final_state, final_time)
            cumulative_surface_flux += (
                fraction * q3.DT *
                0.5 * (previous_flux + crossing_flux)
            )
            break
        final_state = state
        final_time = time

    final_moisture = moisture_content(final_state)
    moisture_change = final_moisture - initial_moisture
    relative_error = abs(
        moisture_change - cumulative_surface_flux
    ) / max(abs(cumulative_surface_flux), 1.0e-16)
    normalized_error = abs(
        moisture_change - cumulative_surface_flux
    ) / max(abs(initial_moisture - final_moisture), 1.0e-16)

    lines = [
        "# 第三问全局水分守恒检验",
        "",
        "## 计算设置",
        "",
        f"二维网格为 Nr={q3.N_RADIAL}、Nz={q3.N_AXIAL}，隐式 RK4 时间步长为 {q3.DT:.1f} s。",
        "",
        "## 守恒结果",
        "",
        f"- 初始水分积分量：{initial_moisture:.10e}",
        f"- 终止水分积分量：{final_moisture:.10e}",
        f"- 内部水分变化量：{moisture_change:.10e}",
        f"- 表面累计传质量：{cumulative_surface_flux:.10e}",
        "",
        f"以表面累计传质量为分母的相对误差为 {relative_error:.6e}。",
        f"以内部水分变化量为分母的归一化误差为 {normalized_error:.6e}。",
        "",
        "## 判定",
        "",
        "若两个误差量级均远小于 1%，则说明内部水分变化与所有表面的对流传质通量基本闭合。",
    ]
    report_path = BASE_DIR / "第三问全局水分守恒检验.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "水分守恒"
    worksheet.append(["项目", "数值"])
    worksheet.append(["初始水分积分量", initial_moisture])
    worksheet.append(["终止水分积分量", final_moisture])
    worksheet.append(["内部水分变化量", moisture_change])
    worksheet.append(["表面累计传质量", cumulative_surface_flux])
    worksheet.append(["相对误差", relative_error])
    worksheet.append(["归一化误差", normalized_error])
    worksheet.append(["终止时间/h", final_time / 3600.0])
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9EAF7")
    for row in worksheet.iter_rows(min_row=2):
        if isinstance(row[1].value, float):
            row[1].number_format = "0.00000000e+00"
    workbook_path = BASE_DIR / "第三问全局水分守恒检验.xlsx"
    workbook.save(workbook_path)

    np.savez_compressed(
        BASE_DIR / "q3_moisture_balance.npz",
        initial_moisture=initial_moisture,
        final_moisture=final_moisture,
        moisture_change=moisture_change,
        cumulative_surface_flux=cumulative_surface_flux,
        relative_error=relative_error,
        normalized_error=normalized_error,
        final_time_s=final_time,
    )

    print(f"initial moisture: {initial_moisture:.10e}")
    print(f"final moisture: {final_moisture:.10e}")
    print(f"moisture change: {moisture_change:.10e}")
    print(f"surface flux: {cumulative_surface_flux:.10e}")
    print(f"relative error: {relative_error:.6e}")
    print(f"normalized error: {normalized_error:.6e}")
    print(f"report: {report_path}")
    print(f"workbook: {workbook_path}")


if __name__ == "__main__":
    main()
